<div class="container">
        <div class="category">
            <h1 class="category__title">hình ảnh  hoạt động</h1>
            <div class="category__line">
                <div class="category__dot">
                    <div class="category__dot-large"></div>
                    <div class="category__dot-small"></div>
                </div>
            </div>
            <p class="category__description">
                Vận tải là sự di chuyển hay chuyển động của người, động vật và hàng hóa từ nơi này đến nơi khác
            </p>               
        </div>
            <div class="library__list">        
                <div class="row">
                    <div class="library__list-item">
                        <img src="<?php  bloginfo('template_directory') ?>/images/005.png" alt="">
                    </div>
                    <div class="library__list-item">
                        <img src="<?php  bloginfo('template_directory') ?>/images/001.jpg" alt="">
                    </div>
                    <div class="library__list-item">
                        <img src="<?php  bloginfo('template_directory') ?>/images/006.jpg" alt="">
                    </div>
                </div>
                <div class="row">
                    <div class="library__list-item">
                        <img src="<?php  bloginfo('template_directory') ?>/images/010.jpg" alt="">
                    </div>
                    <div class="library__list-item">    
                        <img src="<?php  bloginfo('template_directory') ?>/images/008.jpg" alt="">
                    </div>
                    <div class="library__list-item">
                        <img src="<?php  bloginfo('template_directory') ?>/images/009.jpg" alt="">
                    </div>
                </div>
            </div>
</div>