<?php get_header();?>
<div class="container">
    <div class="404">
        <img src="<?php  bloginfo('template_directory') ?>/images/404.png" alt="vantaitamsang.com" srcset="">
    </div>
</div>
<?php get_footer();?>
