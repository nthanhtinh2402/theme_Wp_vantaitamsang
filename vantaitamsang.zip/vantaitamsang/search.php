<?php get_header();?>
Trang đang được cập nhập
<?php get_footer();?>